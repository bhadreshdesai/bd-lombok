package com.example.mvn.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvnDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
